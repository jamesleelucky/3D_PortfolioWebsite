// import React from 'react'
// import { useRef} from 'react';

// const GlowCard = ({card, children, index}) => {
//   const cardRefs = useRef([]);
//   const handleMouseMove = (index) => (e) => {
//     const card = cardRefs.current[index];
//     if (!card) return;

//     const rect = card.getBoundingClientRect();
//     const mouseX = e.clientX - rect.left - rect.width / 2;
//     const mouseY = e.clientY - rect.top - rect.height / 2;

//     let angle = Math.atan2(mouseY, mouseX) * (180 / Math.PI);
//     angle = (angle + 360) % 360;

//     card.style.setProperty('--start', angle + 60);
//   }
//   return (
//     <div className='card card-boarder timeline-card rounded-xl p-10' ref={(el) => (cardRefs.current[index] = el)} onMouseMove={handleMouseMove(index)}>
//       <div className='glow pointer-events-none'/>
//       <div className='flex items-center gap-1 mb-5'>
//         <h1>Technology Used</h1>
//       </div>
//       <div className='mb-5 z-10 relative'>  
//         <p className='text-white-50 text-lg'>{card.techUsed}</p>
//       </div>
//       <div className="mt-4 z-10 relative">
//         {children}
//       </div>
//     </div>
//   )
// }

// export default GlowCard

// import React, { useRef } from 'react';

// const GlowCard = ({ card, children, index }) => {
//   const cardRefs = useRef([]);

//   const handleMouseMove = (index) => (e) => {
//     const card = cardRefs.current[index];
//     if (!card) return;

//     const rect = card.getBoundingClientRect();
//     const mouseX = e.clientX - rect.left - rect.width / 2;
//     const mouseY = e.clientY - rect.top - rect.height / 2;

//     let angle = Math.atan2(mouseY, mouseX) * (180 / Math.PI);
//     angle = (angle + 360) % 360;

//     card.style.setProperty('--start', angle + 60);
//   };

//   return (
//     <div
//       className="relative rounded-xl p-6 bg-[#1a1a1a] shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 h-full flex flex-col justify-between overflow-hidden"
//       ref={(el) => (cardRefs.current[index] = el)}
//       onMouseMove={handleMouseMove(index)}
//     >
//       {/* Glow effect already implemented */}
//       <div className="absolute inset-0 rounded-xl pointer-events-none"></div>
      
//       {/* Card content */}
//       <div className="relative z-10 flex flex-col justify-between h-full">
//         {children}
//       </div>
//     </div>
//   );
// };

// export default GlowCard

import React, { useRef } from 'react';

const GlowCard = ({ card, children, index }) => {
  const cardRefs = useRef([]);

  const handleMouseMove = (index) => (e) => {
    const card = cardRefs.current[index];
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const mouseX = e.clientX - rect.left - rect.width / 2;
    const mouseY = e.clientY - rect.top - rect.height / 2;

    let angle = Math.atan2(mouseY, mouseX) * (180 / Math.PI);
    angle = (angle + 360) % 360;

    card.style.setProperty('--start', angle + 60);
  };

  return (
    <div
      className="relative rounded-xl p-6 bg-[#1a1a1a] shadow-lg hover:shadow-2xl transition-transform duration-300 hover:-translate-y-2 h-full flex flex-col justify-between overflow-hidden"
      ref={(el) => (cardRefs.current[index] = el)}
      onMouseMove={handleMouseMove(index)}
    >
      {/* Glow Layer */}
      <div className="absolute inset-0 rounded-xl pointer-events-none"></div>

      {/* Card Content */}
      <div className="relative z-10 flex flex-col justify-between h-full">{children}</div>
    </div>
  );
};

export default GlowCard;


