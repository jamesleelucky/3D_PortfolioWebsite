import { Canvas } from '@react-three/fiber'
import React from 'react'
import { OrbitControls } from '@react-three/drei'
import {useMediaQuery} from 'react-responsive'
import {Room} from './Room.jsx'
import HeroLights from './HeroLights.jsx'

// const HeroExperience = () => {
//   const isTablet = useMediaQuery({query: '(max-width: 1024px)'});
//   const isMobile = useMediaQuery({query: '(max-width: 768px)'});

//   return (
//     <Canvas camera={{position:[0,0,15], fov:45}}>
//         <OrbitControls enablePan={false} enableZoom={false} maxDistance={20} minDistance={5} minPolarAngle={0} maxPolarAngle={Math.PI}/>
//         <HeroLights />
//         <group scale={isMobile? 2.5 : 4.0} position={[0, -0.5, 0]} rotation={[0, 0, 0]}>
//           <Room />
//         </group>

//     </Canvas>
//   )
// }

const HeroExperience = () => {
  const isTablet = useMediaQuery({ query: '(max-width: 1024px)' });
  const isMobile = useMediaQuery({ query: '(max-width: 768px)' });

  const scaleValue = isMobile ? 2.5 : isTablet ? 3.3 : 3.5;
  const positionValue = isMobile ? [0, -1.5, 0] : isTablet ? [0, -2.0, 0] : [2, 2.2, 0];
  const cameraPosition = isMobile ? [0, 0, 20] : [0, 0, 18];

  return (
    <div className="relative w-full h-[550px] sm:h-[650px] md:h-[750px] lg:h-[850px]">
      <Canvas camera={{ position: cameraPosition, fov: 45 }}>
        <OrbitControls enablePan={false} enableZoom={false} maxDistance={20} minDistance={5} minPolarAngle={0} maxPolarAngle={Math.PI}/>
        <HeroLights />
        <group
          scale={scaleValue}
          position={positionValue}
          rotation={[0, 0, 0]} 
        >
          <Room />
        </group>
      </Canvas>
    </div>
  );
};


export default HeroExperience
