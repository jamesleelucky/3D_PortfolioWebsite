import React from 'react'
import { useGLTF } from '@react-three/drei'
import { Canvas } from '@react-three/fiber';
import { Environment } from '@react-three/drei';
import { Float } from '@react-three/drei';
import { OrbitControls } from '@react-three/drei';

const TechIcon = ({model}) => {
  const scene = useGLTF(model.modelPath);

  return (
    <Canvas>
        <ambientLight intensity={0.3}/>
        <directionalLight position={[5,5,5]} intensity={1}/>
        <OrbitControls enableZoom={false}/>
        <Environment preset="city"/>
        <Float speed={5.5} rotationIntensity={0.5} floatIntensity={0.5}>
            <group scale={model.scale} rotation={model.rotation}>
                <primitive object={scene.scene}/>
            </group>
        </Float>
    </Canvas>
  )
}

export default TechIcon
