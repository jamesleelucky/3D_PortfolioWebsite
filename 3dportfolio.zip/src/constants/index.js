const navLinks = [
    {
      name: "Work",
      link: "#work",
    },
    {
      name: "Experience",
      link: "#experience",
    },
    {
      name: "Skills",
      link: "#skills",
    },
    {
      name: "Testimonials",
      link: "#testimonials",
    },
  ];
  
  const words = [
    { text: "Ideas", imgPath: "/images/ideas.svg" },
    { text: "Concepts", imgPath: "/images/concepts.svg" },
    { text: "Designs", imgPath: "/images/designs.svg" },
    { text: "Code", imgPath: "/images/code.svg" },
    { text: "Ideas", imgPath: "/images/ideas.svg" },
    { text: "Concepts", imgPath: "/images/concepts.svg" },
    { text: "Designs", imgPath: "/images/designs.svg" },
    { text: "Code", imgPath: "/images/code.svg" },
  ];
  
  const counterItems = [
    { value: 3, suffix: "+", label: "Years of Experience" },
    { value: 10, suffix: "+", label: "Technology Mastered" },
    { value: 10, suffix: "+", label: "Completed Projects" },
    { value: 35, suffix: "+", label: "Weekly Coding Hours" },
  ];
  
  const logoIconsList = [
    {
      imgPath: "/images/logos/company-logo-1.png",
    },
    {
      imgPath: "/images/logos/company-logo-2.png",
    },
    {
      imgPath: "/images/logos/company-logo-3.png",
    },
    {
      imgPath: "/images/logos/company-logo-4.png",
    },
    {
      imgPath: "/images/logos/company-logo-5.png",
    },
    {
      imgPath: "/images/logos/company-logo-6.png",
    },
    {
      imgPath: "/images/logos/company-logo-7.png",
    },
    {
      imgPath: "/images/logos/company-logo-8.png",
    },
    {
      imgPath: "/images/logos/company-logo-9.png",
    },
    {
      imgPath: "/images/logos/company-logo-10.png",
    },
    {
      imgPath: "/images/logos/company-logo-11.png",
    },
  ];
  
  const abilities = [
    {
      imgPath: "/images/seo.png",
      title: "Problem Solving",
      desc: "Debugging complex bugs with limited information & Choosing efficient data structures and algorithms.",
    },
    {
      imgPath: "/images/chat.png",
      title: "Clear Communication",
      desc: "Explaining technical decisions to non-technical stakeholders & riting clean documentation or commit messages.",
    },
    {
      imgPath: "/images/time.png",
      title: "Time Management",
      desc: "Making sure projects are completed on schedule, with quality & attention to detail.",
    },
  ];
  
  const techStackImgs = [
    {
      name: "React Developer",
      imgPath: "/images/logos/react.png",
    },
    {
      name: "Python Developer",
      imgPath: "/images/logos/python.svg",
    },
    {
      name: "Backend Developer",
      imgPath: "/images/logos/node.png",
    },
    {
      name: "Interactive Developer",
      imgPath: "/images/logos/three.png",
    },
    {
      name: "Project Manager",
      imgPath: "/images/logos/git.svg",
    },
  ];
  
  const techStackIcons = [
    {
      name: "React",
      modelPath: "/models/react_logo-transformed.glb",
      scale: 1,
      rotation: [0, 0, 0],
    },
    {
      name: "Python",
      modelPath: "/models/python-transformed.glb",
      scale: 0.8,
      rotation: [0, 0, 0],
    },
    
    {
      name: "THREE.js",
      modelPath: "/models/three.js-transformed.glb",
      scale: 0.05,
      rotation: [0, 0, 0],
    },
    {
      name: "Git",
      modelPath: "/models/git-svg-transformed.glb",
      scale: 0.05,
      rotation: [0, -Math.PI / 4, 0],
    },
    {
      name: "Javascript",
      modelPath: "/models/javascript-transformed.glb",
      scale: 0.2,
      rotation: [0, 0, 0],
    }
  ];
  
  const expCards = [
    {
        techUsed: "Microsoft Office Escel",
        imgPath: "/images/exp3.png",
        logoPath: "/images/excel.svg",
        title: "Sergent",
        date: "December 2020 - May 2022",
        responsibilities: [
          "Managed the information of full-time reserves using Microsoft Office Excel",
          "Military support for the civil authorities: COVID-19 test guidance, disinfection, and vaccine temperature checking"
        ],
    },
    {
      techUsed: "Python, JAX, Deep Mapping of Molecular Structures(Deep MMS) Code",
      imgPath: "/images/exp1.png",
      logoPath: "/images/python.png",
      title: "Undergraduate Researcher",
      date: "September 2023 - August 2024",
      responsibilities: [
        "Contributed to research on how to calculate free energy of proteins efficiently using Deep Neural Networks",
        "Implemented Bond-Angle-Torsion system using Python, JAX, and Deep Mapping of Molecular Structures codes",
        "Executed multiple molecular dynamics simulations of approximately 1,000 ps on Jetstream2 supercomputing virtual machines for protein models such as 1-ButamineE",
        "Analyzed and trained data from the simulation, and generated RMSD graphs ranging from 0 to 1.6 ̊A to assess structural stability over time"
      ],
    },
    {
      techUsed: "Javascript, THREE.js, HTML, CSS, PHP",
      imgPath: "/images/exp2.png",
      logoPath: "/images/threejs.png",
      title: "Frontend Developer",
      date: "May 2024 - August 2024",
      responsibilities: [
        "Designed an interactive UI using JavaScript, MathJax, and PHP to visualize right triangles on Cartesian planes, enhancing comprehension of line-length formulas for high school students",
        "Developed animated 3D models of six geometric figures using HTML, CSS, and THREE.js to demonstrate volume concepts, improving learning engagement",
        "Implemented fully responsive web pages optimized for speed and accessibility, achieving 100 Performance and 98 Accessibility on Lighthouse and reducing load time to 0.3s FCP"
      ],
    }
  ];
  
  const expLogos = [
    {
      name: "logo1",
      imgPath: "/images/excel.svg",
    },
    {
      name: "logo2",
      imgPath: "/images/python.png",
    },
    {
      name: "logo3",
      imgPath: "/images/threejs.png",
    },
  ];
  
  const testimonials = [
    {
      name: "Math Tutor Chatbot Charlie (MTCC)",
      techUsed: "Python, OpenAI API, LangChain",
      link:
        "https://github.com/jamesleelucky/MathTutoringChatbotCharlie",
    },
    {
      name: "MyHomeworkRewards Internship Projects",
      techUsed: "THREE.js, PHP, CSS",
      link:
        "https://github.com/jamesleelucky/MyHomeworkRewards/blob/main/length_of_line.php",
      link2: "https://github.com/jamesleelucky/MyHomeworkRewards/blob/main/volume2.php"
    },
    {
      name: "Snake Game",
      techUsed: "OpenCV, Python",
      link:
        "https://github.com/jamesleelucky/SnakeGame/blob/master/main.py",
    },
    {
      name: "Undergraduate Research",
      techUsed: "Python, JAX, DeepMMS code",
      link:
        "https://github.com/jamesleelucky/IIT_ComputationalChemicalBiologyLab/blob/main/custom_encoder_jax.py",
      link2: "https://github.com/jamesleelucky/IIT_ComputationalChemicalBiologyLab/blob/main/BAT_jax.py"
    },
    {
      name: "3D Portfolio Website",
      techUsed: "React.js, THREE.js, CSS",
      link:
        "",
    },
    {
      name: "",
      techUsed: "",
      link:
        "",
    }
  ];
  
  const socialImgs = [
    {
      name: "insta",
      imgPath: "/images/insta.png",
    },
    {
      name: "fb",
      imgPath: "/images/fb.png",
    },
    {
      name: "x",
      imgPath: "/images/x.png",
    },
    {
      name: "linkedin",
      imgPath: "/images/linkedin.png",
    },
  ];
  
  export {
    words,
    abilities,
    logoIconsList,
    counterItems,
    expCards,
    expLogos,
    testimonials,
    socialImgs,
    techStackIcons,
    techStackImgs,
    navLinks,
  };