// import { expCards } from '../constants/index.js'
// import GlowCard from '../components/GlowCard.jsx'
// import TitleHeader from '../components/TitleHeader.jsx'
// import gsap from 'gsap'
// import { useGSAP } from '@gsap/react'
// import {ScrollTrigger} from 'gsap/ScrollTrigger'

// gsap.registerPlugin(ScrollTrigger);

// const ExperienceSection = () => {
//   useGSAP(() => {
//     gsap.utils.toArray('.timeline-card').forEach((card) => {
//         gsap.from(card, {
//             xPercent: -100,
//             opacity: 0,
//             transformOrigin: 'left left',
//             duration: 1,
//             ease: 'power2.inOut',
//             scrollTrigger: {
//                 trigger: card,
//                 start: 'top 80%'
//             }
//         })
//     })
//     gsap.to('.timeline', {
//         transformOrigin: 'bottom bottom',
//         ease: 'power1.inOut',
//         scrollTrigger: {
//             trigger: '.timeline',
//             start: 'top center',
//             end: '70% center',
//             onUpdate: (self) => {
//                 gsap.to('.timeline', {
//                     scaleY: 1-self.progress
//                 })
//             }
//         }
//     })
//     gsap.utils.toArray('.expText').forEach((text) => {
//         gsap.from(text, {
//             xPercent: 0,
//             opacity: 0,
//             duration: 1,
//             ease: 'power2.inOut',
//             scrollTrigger: {
//                 trigger: text,
//                 start: 'top 80%'
//             }
//         })
//     })
//   },[]);
//   return (
//     <section id='experience' className='w-full md:mt-10 mt-5 section-padding xl:px-0'>
//       <div className="w-full h-full md:px-20 px-5">
//         <TitleHeader title="Professional Work Experience" sub="My Career Overview"/>
//         <div className='mt-32 relative'>
//             <div className='relative z-50 xl:space-y-32 space-y-10'>
//                 {expCards.map((card, index) => (
//                     <div key={card.title} className='exp-card-wrapper'>
//                         <div className="w-full md:w-1/3">
//                             <GlowCard card={card} index={index}>
//                                 <div className="flex flex-col items-start gap-3">
//                                     {/* Job Title */}
//                                     <h3 className="text-xl font-semibold text-white">{card.title}</h3>

//                                     {/* Tech Stack */}
//                                     <div className="flex flex-wrap gap-2 mt-2">
//                                     {card.techUsed && card.techUsed.split(',').map((tech, idx) => (
//                                         <span
//                                             key={idx}
//                                             className="bg-gray-700 text-white text-xs px-2 py-1 rounded-lg border border-gray-500"
//                                         >
//                                         {tech.trim()}
//                                         </span>
//                                     ))}
//                                     </div>
//                                 </div>
//                             </GlowCard>
//                         </div>
//                         <div className='w-full md:w-2/3 mt-6 md:mt-0'>
//                             <div className='flex items-start'>
//                                 <div className='timeline-wrapper'>
//                                     <div className='timeline'/>
//                                     <div className='gradient-line w-1 h-full'/>
//                                 </div>

//                                 <div className='expText flex xl:gap-20 md: gap-10 gap-5 relative z-20'>
//                                     {/* <div className='timeline-logo'>
//                                         <img src={card.logoPath} alt="logo" />
//                                     </div> */}
//                                     <div className="timeline-logo w-16 h-16 rounded-full overflow-hidden flex items-center justify-center bg-gray-800">
//                                         <img src={card.logoPath} alt="logo" className="w-10 h-10 object-contain" />
//                                     </div>

//                                     <div>
//                                         <h1 className='font-semi-bold text-3xl'>{card.title}</h1>
//                                         <p className='my-5 text-white-50'>
//                                             {card.date}
//                                         </p>
//                                         <p className='text-[#839cb5] italic'>
//                                             Responsibilities
//                                         </p>
//                                         <ul className='list-disc ms-5 mt-5 flex flex-col gap-5 text-white-50'>
//                                             {card.responsibilities.map((responsibility) => (
//                                                 <li className='text-lg' key={responsibility}>
//                                                     {responsibility}
//                                                 </li>
//                                             ))}
//                                         </ul>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 ))}
//             </div>
//         </div>
//       </div>
//     </section>
//   )
// }

// export default ExperienceSection

import { expCards } from '../constants/index.js';
import GlowCard from '../components/GlowCard.jsx';
import TitleHeader from '../components/TitleHeader.jsx';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import React from 'react';

gsap.registerPlugin(ScrollTrigger);

const ExperienceSection = () => {
  useGSAP(() => {
    // GlowCards slide in from left
    gsap.utils.toArray('.glow-card-anim').forEach((card) => {
      gsap.fromTo(
        card,
        { x: -50 },
        {
          x: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    });

    // Details slide in from right
    gsap.utils.toArray('.exp-details').forEach((detail) => {
      gsap.fromTo(
        detail,
        { x: 50 },
        {
          x: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: detail,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    });

    // Timeline gradient scroll animation
    gsap.fromTo(
      '.timeline-gradient',
      { scaleY: 0 },
      {
        scaleY: 1,
        transformOrigin: 'top center',
        ease: 'none',
        scrollTrigger: {
          trigger: '.timeline-column',
          start: 'top top',
          end: 'bottom bottom',
          scrub: true,
        },
      }
    );

    // Logos scale slightly on scroll
    gsap.utils.toArray('.timeline-logo').forEach((logo) => {
      gsap.fromTo(
        logo,
        { scale: 0.8 },
        {
          scale: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: logo,
            start: 'top 85%',
            end: 'bottom 65%',
            scrub: true,
          },
        }
      );
    });
  }, []);

  return (
    <section id="experience" className="w-full section-padding xl:px-0">
      <div className="w-full md:px-10 px-4">
        <TitleHeader title="Professional Work Experience" sub="My Career Overview" />

        {/* Grid Layout: GlowCards | Timeline | Details */}
        <div className="mt-16 grid grid-cols-3 gap-2 sm:gap-4 lg:gap-6 relative">
          {/* Full timeline gradient */}
          <div className="absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-1 bg-gray-700">
            <div className="timeline-gradient w-full h-full bg-gradient-to-b from-purple-500 to-pink-500 scale-y-0"></div>
          </div>

          {expCards.map((card) => (
            <React.Fragment key={card.title}>
              {/* GlowCard Column */}
              <div className="glow-card-anim flex justify-end pr-1 sm:pr-2">
                <GlowCard card={card}>
                  <div className="flex flex-col items-start gap-3">
                    <h3 className="text-base sm:text-lg font-semibold text-white">{card.title}</h3>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {card.techUsed &&
                        card.techUsed.split(',').map((tech, idx) => (
                          <span
                            key={idx}
                            className="bg-gray-700 text-white text-xs px-2 py-1 rounded-lg border border-gray-500"
                          >
                            {tech.trim()}
                          </span>
                        ))}
                    </div>
                  </div>
                </GlowCard>
              </div>

              {/* Timeline Logo Column */}
              <div className="flex items-center justify-center timeline-column">
                <div className="timeline-logo w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gray-800 flex items-center justify-center overflow-hidden shadow-md z-10">
                  <img src={card.logoPath} alt="logo" className="w-7 h-7 sm:w-8 sm:h-8 object-contain" />
                </div>
              </div>

              {/* Details Column */}
              <div className="exp-details flex flex-col justify-center pl-1 sm:pl-2">
                <h1 className="text-base sm:text-xl font-semibold text-white">{card.title}</h1>
                <p className="text-white-50">{card.date}</p>
                <p className="text-[#839cb5] italic">Responsibilities</p>
                <ul className="list-disc ms-5 mt-3 flex flex-col gap-2 text-white-50">
                  {card.responsibilities.map((responsibility) => (
                    <li className="text-xs sm:text-sm md:text-base" key={responsibility}>
                      {responsibility}
                    </li>
                  ))}
                </ul>
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
