import React from 'react';
import { words } from '../constants/index.js';
import Button from '../components/Button.jsx';
import HeroExperience from '../components/HeroModels/HeroExperience.jsx';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import AnimatedCounter from '../components/AnimatedCounter.jsx';

const Hero = () => {
  useGSAP(() => {
    gsap.fromTo('.hero-text h1',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, stagger: 0.2, duration: 1, ease: 'power2.inOut' }
    );
  });

  return (
    <section id="hero" className="relative overflow-hidden lg:pt-[110px]">
      {/* Background */}
      <div className="absolute top-0 left-0 z-0">
        <img src="/images/bg.png" alt="background" />
      </div>

      <div className="hero-layout flex flex-col md:flex-row items-center md:items-start justify-between md:px-20 px-5">
        {/* LEFT: TEXT */}
        <header className="flex flex-col justify-center w-full gap-3 text-center md:text-left">
          <div className="hero-text">
            {/* First line */}
            <h1 className=" text-left text-[2.8rem] sm:text-[3.2rem] md:text-[4rem] lg:text-[4.5rem] font-bold leading-tight relative-ml-4">
              Transform
              {/* Animated word stays inline for md+ but breaks for mobile */}
              <span className="sm:inline">
                <span className="slide">
                  <span className="wrapper">
                    {words.map((word) => (
                      <span
                        key={word.text}
                        className="flex items-center gap-1 md:gap-3 "
                      >
                        <span>{word.text}</span>
                      </span>
                    ))}
                  </span>
                </span>
              </span>
            </h1>

            {/* Next lines (pushed down for mobile when above becomes 2 lines) */}
            <h1 className="text-left mt-[3px] text-[2.8rem] sm:text-[3.2rem] md:text-[4rem] lg:text-[4.5rem] font-bold leading-tight">
              into Software
            </h1>
            <h1 className="text-left text-[2.8rem] sm:text-[3.2rem] md:text-[4rem] lg:text-[4.5rem] font-bold leading-tight">
              that Matters
            </h1>
          </div>

          {/* Subtext */}
          <p className="text-left text-white-50 text-lg sm:text-xl md:text-2xl md:text-left max-w-2xl md:max-w-none">
            Hi, I am Beomjong, a CS student at University of Wisconsin-Madison!
          </p>

          {/* Button */}
          <div className="flex justify-left md:justify-start lg:pt-[10px]">
            <Button className="md:w-80 md:h-16 w-60 h-12" id="button" text="See My Work" />
          </div>
        </header>

        {/* RIGHT: EARTH MODEL */}
        <figure className="hero-3d-layout mt-10 md:mt-0">
          <HeroExperience />
        </figure>
      </div>

      <AnimatedCounter />
    </section>
  );
};

export default Hero;

