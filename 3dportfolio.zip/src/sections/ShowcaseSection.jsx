import { useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(ScrollTrigger);

const ShowcaseSection = () => {
  const sectionRef = useRef(null);
  const chatbotRef = useRef(null);
  const myhomeworkrewardsRef = useRef(null);
  const todolistRef = useRef(null);

  const projects = [chatbotRef.current, myhomeworkrewardsRef.current, todolistRef.current];

  useGSAP(() => {
    projects.forEach((card, index) => {
      gsap.fromTo(
          card,
          {
              y: 50,
              opacity: 0
          },
          {
              y: 0,
              duration: 1,
              delay: 0.3* (index + 1),
              scrollTrigger: {
                  trigger: card,
                  start: 'top bottom-=100',
              }
          }
      )
    })
    gsap.fromTo(
        sectionRef.current,
        {opacity: 0},
        {opacity: 1, duration: 1.5}
    )
  }, [])

  return (
    <section id='work' ref={sectionRef} className='app-showcase'>
      <div className="w-full">
        <div className="showcaselayout">
            {/* LEFT */}
            <div className='first-project-wrapper' ref={chatbotRef}>
                <div className='image-wrapper'>
                    <img src="/images/chatbot.png" alt="AI-Chatbot" />
                </div>
                <div className="text-content">
                    <h2>Math Tutoring Chatbot Charlie</h2>
                    <p>Designed and developed an interactive math tutor chatbot using Streamlit and LangChain to process multiple PDFs and deliver accurate, step-by-step solutions</p>
                    <p>Used Python, Langchain, OpenAI API, and Streamlit</p>
                </div>
            </div>
            {/* RIGHT */}
            <div className='project-list-wrapper overflow-hidden'>
                <div className="project" ref={myhomeworkrewardsRef}>
                    <div className='image-wrapper bg-[#d87f3a]'>
                        <img src="/images/myhomeworkrewards.png" alt="internship" />
                    </div>
                    <h2>Internship Project at MyHomeworkRewards</h2>
                    <p>Designed an interactive UI using JavaScript, MathJax, and PHP to visualize right triangles on Cartesian planes, enhancing comprehension of line-length formulas for high school students</p>
                </div>
                <div className="project" ref={todolistRef}>
                    <div className='image-wrapper bg-[#668faf]'>
                        <img src="/images/snakegame.png" alt="snakegame" />
                    </div>
                    <h2>Snake Game</h2>
                    <p>Developed a gesture-controlled Snake game using Python and OpenCV, enabling real-time hand tracking for intuitive gameplay.</p>
                </div>
            </div>
        </div>
      </div> 
    </section>
  )
}

export default ShowcaseSection
