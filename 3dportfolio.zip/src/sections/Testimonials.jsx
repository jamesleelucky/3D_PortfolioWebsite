// import React from 'react'
// import TitleHeader from '../components/TitleHeader'
// import { testimonials } from '../constants'
// import GlowCard from '../components/GlowCard'

// const Testimonials = () => {
//   return (
//    <section id='testimonials' className='flex-center section-padding'>
//     <div className='w-full h-full md:px-10 px-5'>
//         <TitleHeader title="Testimonials of My Work Experience and Projects" sub="Testimonials"/>
//         <div className='grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-6 mt-16'>
//             {testimonials.map((testimonial) => ( 
//                 <GlowCard card={testimonial} key={testimonial.name}>
//                     <div className='flex flex-col gap-3 p-4'>
//                         <h3 className='text-xl font-semibold text-white'>{testimonial.name}</h3>
//                     </div>
//                     <div className="text-blue-400 underline hover:text-blue-300">
//                          <a href={testimonial.link} >View my project: </a>
//                     </div>
//                 </GlowCard>
//             ))}
//         </div>
//     </div>
//    </section>
//   )
// }

// export default Testimonials

import React from 'react';
import TitleHeader from '../components/TitleHeader';
import GlowCard from '../components/GlowCard';
import { testimonials } from '../constants';

const Testimonials = () => {
  return (
    <section id="testimonials" className="flex-center section-padding">
      <div className="w-full h-full md:px-10 px-5">
        <TitleHeader title="Testimonials of My Work Experience and Projects" sub="Testimonials" />

        <div className="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-8 mt-16">
          {testimonials.map((testimonial, index) => (
            <GlowCard card={testimonial} key={testimonial.name} index={index}>
              {/* Project Title */}
              <h3 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-200 via-gray-100 to-white mb-4">
                {testimonial.name}
              </h3>

              {/* Tech Stack Badges */}
              <div className="flex flex-wrap gap-2 mb-4">
                {testimonial.techUsed.split(',').map((tech, i) => (
                  <span
                    key={i}
                    className="bg-gray-700 text-white text-xs px-2 py-1 rounded-lg border border-gray-500"
                  >
                    {tech.trim()}
                  </span>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="mt-auto flex gap-3">
                {testimonial.link && (
                  <a
                    href={testimonial.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 text-sm text-white bg-blue-500 hover:bg-blue-400 rounded-lg transition"
                  >
                    View Project
                  </a>
                )}
                {testimonial.link2 && (
                  <a
                    href={testimonial.link2}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 text-sm text-white bg-purple-500 hover:bg-purple-400 rounded-lg transition"
                  >
                    View More
                  </a>
                )}
              </div>
            </GlowCard>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
